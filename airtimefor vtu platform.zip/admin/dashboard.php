<?php
// Database connection (adjust credentials accordingly)
include("connection.php");
// Fetch dynamic stats
$totalUsers = $conn->query("SELECT COUNT(*) AS count FROM vtu_users")->fetch_assoc()['count'];
$walletBalance = $conn->query("SELECT SUM(wallet_balance) AS total FROM vtu_users")->fetch_assoc()['total'];
$todayRevenue = $conn->query("SELECT SUM(amount) AS revenue FROM transactions WHERE DATE(date) = CURDATE() AND status = 'success'")->fetch_assoc()['revenue'];
$failedTxns = $conn->query("SELECT COUNT(*) AS count FROM transactions WHERE DATE(date) = CURDATE() AND status = 'failed'")->fetch_assoc()['count'];
$monthlyProfit = $conn->query("SELECT SUM(profit) AS total FROM transactions WHERE MONTH(date) = MONTH(CURDATE()) AND YEAR(date) = YEAR(CURDATE())")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
  <script>
    function toggleSidebar() {
      document.getElementById('sidebar').classList.toggle('hidden');
    }
  </script>
</head>
<body class="bg-gray-100 dark:bg-black text-gray-900 dark:text-white">
  <!-- Sidebar -->
  <div class="md:flex">
    <div id="sidebar" class="w-full md:w-1/4 bg-white dark:bg-gray-800 p-4 hidden md:block">
      <h2 class="text-xl font-bold mb-4">RechargeHub Admin</h2>
      <ul class="space-y-2">
        <li><a href="#" class="block p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700">Dashboard</a></li>
        <li><a href="#" class="block p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700">Users</a></li>
        <li><a href="#" class="block p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700">Transactions</a></li>
        <li><a href="#" class="block p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700">Add Services</a></li>
        <li><a href="#" class="block p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700">Profits</a></li>
        <li><a href="#" class="block p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-700">Settings</a></li>
      </ul>
    </div>

    <!-- Main Content -->
    <div class="w-full md:w-3/4">
      <!-- Topbar -->
      <div class="flex justify-between items-center px-4 py-6 md:px-10">
        <button class="md:hidden bg-gray-200 dark:bg-gray-700 px-3 py-2 rounded" onclick="toggleSidebar()">☰</button>
        <h1 class="text-2xl md:text-3xl font-bold">Welcome, Admin Chioma</h1>
        <div class="flex items-center gap-4">
          <button class="flex items-center gap-2 bg-gray-200 dark:bg-gray-700 px-3 py-2 rounded shadow">
            🔔 Alerts
          </button>
          <button class="flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white px-3 py-2 rounded shadow">
            🚪 Logout
          </button>
        </div>
      </div>

      <!-- Stats Cards -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 px-4 md:px-10">
        <div class="bg-white dark:bg-gray-900 p-4 rounded-2xl shadow-md">
          <div class="text-3xl mb-2">👥</div>
          <p class="text-sm text-gray-500">Total Users</p>
          <h2 class="text-xl font-bold"><?php echo $totalUsers; ?></h2>
        </div>
        <div class="bg-white dark:bg-gray-900 p-4 rounded-2xl shadow-md">
          <div class="text-3xl mb-2">💼</div>
          <p class="text-sm text-gray-500">Wallet Balance</p>
          <h2 class="text-xl font-bold">₦<?php echo number_format($walletBalance); ?></h2>
        </div>
        <div class="bg-white dark:bg-gray-900 p-4 rounded-2xl shadow-md">
          <div class="text-3xl mb-2">💰</div>
          <p class="text-sm text-gray-500">Today's Revenue</p>
         <h2 class="text-xl font-bold">₦<?php echo number_format($walletBalance ?? 0); ?></h2>

        </div>
        <div class="bg-white dark:bg-gray-900 p-4 rounded-2xl shadow-md">
          <div class="text-3xl mb-2">❌</div>
          <p class="text-sm text-gray-500">Failed Transactions</p>
          <h2 class="text-xl font-bold"><?php echo $failedTxns; ?></h2>
        </div>
        <div class="bg-white dark:bg-gray-900 p-4 rounded-2xl shadow-md">
          <div class="text-3xl mb-2">📈</div>
          <p class="text-sm text-gray-500">Monthly Profit</p>
         <h2 class="text-xl font-bold">₦<?php echo number_format($monthlyProfit ?? 0); ?></h2>

        </div>
      </div>

      <!-- Animation -->
      <div class="flex justify-center mt-10">
        <lottie-player
          src="https://assets4.lottiefiles.com/packages/lf20_5ngs2ksb.json"
          background="transparent"
          speed="1"
          style="width: 200px; height: 200px"
          loop
          autoplay
        ></lottie-player>
      </div>
    </div>
  </div>
</body>
</html>
