<?php
session_start();

// if (!isset($_SESSION['admin_logged_in'])) {
//   header("Location: ../login.php");
//   exit();
// }
include "header.php";

include("connection.php");
$success = $error = '';

// Handle edit request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_id'])) {
  $id = intval($_POST['edit_id']);
  $fullname = trim($_POST['fullname']);
  $email = trim($_POST['email']);
  $wallet = floatval($_POST['wallet_balance']);

  $stmt = $conn->prepare("UPDATE vtu_users SET fullname = ?, email = ?, wallet_balance = ? WHERE id = ?");
  $stmt->bind_param("ssdi", $fullname, $email, $wallet, $id);
  if ($stmt->execute()) {
    $success = "User updated successfully.";
  } else {
    $error = "Error updating user.";
  }
  $stmt->close();
}

// Handle delete request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
  $id = intval($_POST['delete_id']);
  if ($conn->query("DELETE FROM vtu_users WHERE id = $id")) {
    $success = "User deleted successfully.";
  } else {
    $error = "Error deleting user.";
  }
}

$users = $conn->query("SELECT id, fullname, email, wallet_balance, created_at FROM vtu_users ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>VTU Admin - Users</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 text-gray-900 dark:bg-black dark:text-white">
  <div class="container mx-auto px-4 py-10">
    <h2 class="text-2xl font-bold mb-6">Registered Users</h2>

    <?php if ($success): ?>
      <div class="bg-green-100 text-green-800 px-4 py-3 rounded mb-4">
        <?php echo $success; ?>
      </div>
    <?php endif; ?>

    <?php if ($error): ?>
      <div class="bg-red-100 text-red-800 px-4 py-3 rounded mb-4">
        <?php echo $error; ?>
      </div>
    <?php endif; ?>

    <div class="overflow-x-auto bg-white dark:bg-gray-900 shadow-md rounded-lg">
      <table class="min-w-full text-sm">
        <thead class="bg-gray-200 dark:bg-gray-700 text-left">
          <tr>
            <th class="p-3">#</th>
            <th class="p-3">Full Name</th>
            <th class="p-3">Email</th>
            <th class="p-3">Wallet</th>
            <th class="p-3">Date Registered</th>
            <th class="p-3">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php $sn = 1; while ($row = $users->fetch_assoc()): ?>
            <tr class="border-t border-gray-200 dark:border-gray-700">
              <td class="p-3">#<?php echo $sn++; ?></td>
              <form method="POST" action="">
                <td class="p-3">
                  <input type="text" name="fullname" value="<?php echo htmlspecialchars($row['fullname']); ?>" class="bg-transparent border-b border-gray-300 w-full">
                </td>
                <td class="p-3">
                  <input type="email" name="email" value="<?php echo htmlspecialchars($row['email']); ?>" class="bg-transparent border-b border-gray-300 w-full">
                </td>
                <td class="p-3">
                  <input type="number" step="0.01" name="wallet_balance" value="<?php echo $row['wallet_balance']; ?>" class="bg-transparent border-b border-gray-300 w-full">
                </td>
                <td class="p-3"><?php echo date("d M Y", strtotime($row['created_at'])); ?></td>
                <td class="p-3 flex gap-2">
                  <input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" class="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded text-xs">Update</button>
              </form>
              <form method="POST" action="" onsubmit="return confirm('Are you sure you want to delete this user?')">
                <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-xs">Delete</button>
              </form>
                </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
